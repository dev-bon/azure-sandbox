import os
import random
import sys
import webbrowser
import pyautogui
import time

pyautogui.FAILSAFE = False


# pip install pyautogui


def openURL(url):
    webbrowser.get('chrome').open(url, new=1)


class adTraffic:
    chromePath = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
    # create urls.txt and place all your links there
    urlList = 'urls.txt'
    count = 1

    def registerBrowser(self):
        webbrowser.register('chrome', None, webbrowser.BackgroundBrowser(self.chromePath))

    def getUrlList(self):
        urls = open(self.urlList).read().splitlines()
        return urls

    def start(self):
        while True:
            try:
                self.registerBrowser()
                urls = self.getUrlList()
                for url in random.sample(urls, len(urls)):
                    print(f'Sessions left: {self.count}/{len(urls)}')
                    print(f'{self.count}. {url}')
                    openURL(url)
                    time.sleep(15)
                    self.count = self.count + 1
                else:
                    pass
                    print("Closing Browser...")
                    with pyautogui.hold('ctrl'):
                        pyautogui.press('W')

                    # use this on RDP
                    # os.system("taskkill /im chrome.exe /f")
                    self.count = 1
                    time.sleep(10)

            except KeyboardInterrupt:
                print('Stopping Service...')
                sys.exit(0)
            except Exception as e:
                print(e)
                self.start()


if __name__ == '__main__':
    traffic = adTraffic()
    traffic.start()
